
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

@pragma('vm:entry-point')
Future<void> _bgHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_bgHandler);
  runApp(const LottoApp());
}

class LottoApp extends StatelessWidget {
  const LottoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lotto 5/35 Notifier',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.red),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String token = "Dang lay FCM token...";
  String lastResult = "Chua co du lieu. Cho GitHub Actions gui ve.";

  @override
  void initState() {
    super.initState();
    initFCM();
  }

  Future<void> initFCM() async {
    await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
    String? t = await FirebaseMessaging.instance.getToken();
    setState(() => token = t ?? "Khong lay duoc token");
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      setState(() {
        lastResult = message.notification?.body ?? "Co thong bao moi";
      });
    });
  }

  Future<void> sendSMS(List<int> nums, int db) async {
    String body = "L535 ${nums.join(' ')} $db";
    final uri = Uri.parse("sms:9141?body=${Uri.encodeComponent(body)}");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Lotto 5/35 - Tu dong")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: Colors.red.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("KET QUA MOI NHAT", style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text(lastResult),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text("DU DOAN GOI Y - Bam icon SMS de mua ve", style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _predCard([11,12,14,29,31], 7, "Bo 1 (so nong)"),
            _predCard([3,6,10,16,31], 2, "Bo 2 (so gan)"),
            _predCard([4,22,25,28,35], 3, "Bo 3 (can bang)"),
            const SizedBox(height: 24),
            const Divider(),
            const Text("FCM TOKEN - Copy dan vao GitHub Secrets", style: TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            SelectableText(token, style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: token));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Da copy token!")));
              },
              icon: const Icon(Icons.copy),
              label: const Text("COPY TOKEN"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _predCard(List<int> nums, int db, String label) {
    return Card(
      child: ListTile(
        title: Text("${nums.join(' - ')} + DB: $db"),
        subtitle: Text(label),
        trailing: IconButton(
          icon: const Icon(Icons.sms, color: Colors.red),
          onPressed: () => sendSMS(nums, db),
        ),
      ),
    );
  }
}
