package com.lotto535.notifier
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
